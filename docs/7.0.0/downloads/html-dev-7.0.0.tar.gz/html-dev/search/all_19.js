var searchData=
[
  ['ymodel_5497',['yModel',['../classDakota_1_1NonDAdaptiveSampling.html#a86bcbf2c9b29e0266600563cef4c8ca3',1,'Dakota::NonDAdaptiveSampling']]],
  ['ytrue_5498',['yTrue',['../classDakota_1_1NonDAdaptiveSampling.html#a9b47982cec93d338d5d20eff3479fde1',1,'Dakota::NonDAdaptiveSampling']]]
];
