var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijklmnopqrstuvw",
  2: "ds",
  3: "djlmqrs",
  4: "abcdefghijklmnopqrstuvwxz~",
  5: "_abcdefghijklmnopqrstuvwxy",
  6: "abdfgimprsuv",
  7: "cdelmorsv",
  8: "adekmosuv",
  9: "bdhinoprs",
  10: "l",
  11: "acdimptuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Modules",
  11: "Pages"
};

