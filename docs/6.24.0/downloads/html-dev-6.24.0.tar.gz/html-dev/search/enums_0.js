var searchData=
[
  ['cg_5flinesearchtype_12855',['CG_LINESEARCHTYPE',['../namespaceDakota.html#ad3b268d8c7dcee0fd85a51480c0dc46c',1,'Dakota']]],
  ['cg_5fupdatetype_12856',['CG_UPDATETYPE',['../namespaceDakota.html#a870c06cf2d56327e483eaefc1faa917a',1,'Dakota']]]
];
